# DEF-to-SVG
A web-based application for visualizing a DEF file by Scalable vector Graphics (SVG).

This project was done for Digital Design II course at the American University in Cairo (AUC)

To run this application, download the repo and open index.html using any of the latest web browsers.


